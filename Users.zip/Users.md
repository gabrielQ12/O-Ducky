**ARTICLE** (<ins>article_identifier</ins>, title, content, pic, price)<br>
**COMMENTS** (<ins>_#user_identifier_</ins>, <ins>_#article_identifier_</ins>, content)<br>
**CONTAINS** (<ins>_#article_identifier_</ins>, <ins>_#order_identifier_</ins>, quantity)<br>
**ORDER** (<ins>order_identifier</ins>, status, _#user_identifier_)<br>
**USER** (<ins>user_identifier</ins>, name, mail, password)